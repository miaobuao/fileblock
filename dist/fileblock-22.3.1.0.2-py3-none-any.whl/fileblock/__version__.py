__title__ = 'fileblock'
__description__ = 'simplify file processing'
__version__ = '22.3.1.0.2'
__url__ = "http://github.com/miaobuao/fileblock"
__author__ = '喵不嗷'
__author_email__ = '617802189@qq.com'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright 2022 miaobuao'